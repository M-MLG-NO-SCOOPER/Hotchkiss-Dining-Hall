//
//  MealItem.swift
//  HDH
//
//  Created by Student on 11/15/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import Foundation

struct MealItem: CustomStringConvertible {
    
    var name: String
    var descript: String
    var station: Station
    var filter: [String]
    var myID: Int
    static var nextID: Int = 0
    
    var description: String{
        return "Meal(name: \(name), description: \(descript), station: \(station), filter: \(filter), myID: \(myID))"
    }
    
    init(name: String, descript: String, station: Station, filter: [String]) {
        self.name = name
        self.descript = descript
        self.station = station
        self.filter = filter
        self.myID = MealItem.nextID + 1
        MealItem.nextID += 1
    }
    
    enum Station{
        case soupStation
        case saladBar
        case sandwhichBar
        case mainLine
        case cerealBar
    }
    
}
