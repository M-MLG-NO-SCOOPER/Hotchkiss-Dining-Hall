//
//  MealChoiceViewController.swift
//  HDH
//
//  Created by Student on 12/1/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import UIKit

var ratings: [String: Int?] = ["Sriracha Chicken": nil, "Frosted Flakes": nil,"Clam Chowder": nil, "Caramelized Onions": nil]

class MealChoiceViewController: UIViewController {

    let image = UIImage(named: "bluestar")
    let emptyImage = UIImage(named: "emptystar")
    
    @IBOutlet weak var DFLogo: UIImageView!
    @IBOutlet weak var FFLogo: UIImageView!
    @IBOutlet weak var GFLogo: UIImageView!
    @IBOutlet weak var HSLogo: UIImageView!
    @IBOutlet weak var LLogo: UIImageView!
    @IBOutlet weak var OLogo: UIImageView!
    @IBOutlet weak var VLogo: UIImageView!
    @IBOutlet weak var VGLogo: UIImageView!
    
    @IBOutlet weak var FoodImage: UIImageView!
    @IBOutlet weak var descriptionLabel: UITextView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var thanksLabel: UILabel!
    var pic: UIImage?
    var name: String?
    var descript: String?
    @IBOutlet var ratingCollection: [UIButton]!
        
    var filter: [String]?
    var rating = 0
    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        FoodImage.image = pic
        nameLabel.text = name
        descriptionLabel.text = descript
        
        filterSetup()
        
    }

    override func viewDidAppear(_ animated: Bool) {
        for number in 1...5{
            ratingCollection[number-1].isEnabled = true
        }
        
        if let value = ratings[name!] {
            if let unwrappedValue = value {
                for number in 1...unwrappedValue{
                    updateRatingImage(num: number-1)
                    thanksLabel.text = "Rating submitted"
                    
                    ratingCollection[number-1].isEnabled = false
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func button1(_ sender: UIButton) {
        resetImage()
        updateRatingImage(num: 0)
        rating = 1
    }
    @IBAction func button2(_ sender: UIButton) {
        resetImage()
        for num in 0...1{
            updateRatingImage(num: num)
        }
        rating = 2
    }
    @IBAction func button3(_ sender: UIButton) {
        resetImage()
        for num in 0...2{
            updateRatingImage(num: num)
        }
        rating = 3
    }
    @IBAction func button4(_ sender: UIButton) {
        resetImage()
        for num in 0...3{
            updateRatingImage(num: num)
        }
        rating = 4
    }
    @IBAction func button5(_ sender: UIButton) {
       resetImage()
        for num in 0...4{
            updateRatingImage(num: num)
        }
        rating = 5
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        if rating == 0{
            thanksLabel.text = "Please choose a rating"
        }else{
            for num in 0...4{
                ratingCollection[num].isEnabled = false
            }
            thanksLabel.text = "Rating submitted"
            count += 1
            if(count <= 1){
                //print(rating!)
            }
            else{
                print("rating submitted")
            }
            updateRating()
        }
    }
    
    func updateRatingImage(num: Int){
        ratingCollection[num].setImage(image, for: .normal)
    }
    func resetImage(){
        for num in 0...4{
            ratingCollection[num].setImage(emptyImage, for: .normal)
        }
    }
    
    func filterSetup(){
        for filterElement in filter!{
            if filterElement == "Dairy Free"{
                DFLogo.image = UIImage(named: "DF")
            }else if filterElement == "Hotchkiss Grown"{
                FFLogo.image = UIImage(named: "FF")
            }else if filterElement == "Gluten Free"{
                GFLogo.image = UIImage(named: "GF")
            }else if filterElement == "House Smoked"{
                HSLogo.image = UIImage(named: "HS")
            }else if filterElement == "Local"{
                LLogo.image = UIImage(named: "L")
            }else if filterElement == "Organic"{
                OLogo.image = UIImage(named: "O")
            }else if filterElement == "Vegetarian"{
                VLogo.image = UIImage(named: "V")
            }else if filterElement == "Vegan"{
                VGLogo.image = UIImage(named: "VG")
            }
        }
    }

    func updateRating(){
        for num in 0...3{
            if name == Array(ratings.keys)[num]{
                ratings.updateValue(rating, forKey: name!)
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
