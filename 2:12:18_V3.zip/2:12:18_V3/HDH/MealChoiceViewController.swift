//
//  MealChoiceViewController.swift
//  HDH
//
//  Created by Student on 12/1/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import UIKit

class MealChoiceViewController: UIViewController {

    let image = UIImage(named: "bluestar")
    let emptyImage = UIImage(named: "emptystar")
    
    @IBOutlet weak var FoodImage: UIImageView!
    @IBOutlet weak var descriptionLabel: UITextView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var thanksLabel: UILabel!
    var pic: UIImage?
    var name: String?
    var descript: String?
    @IBOutlet var ratingCollection: [UIButton]!
    
    var rating = 0
    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        FoodImage.image = pic
        nameLabel.text = name
        descriptionLabel.text = descript
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func button1(_ sender: UIButton) {
        resetImage()
        sender.setImage(image, for: .normal)
        rating = 1
    }
    @IBAction func button2(_ sender: UIButton) {
        resetImage()
        for num in 0...1{
            ratingCollection[num].setImage(image, for: .normal)
        }
        rating = 2
    }
    @IBAction func button3(_ sender: UIButton) {
        resetImage()
        for num in 0...2{
            ratingCollection[num].setImage(image, for: .normal)
        }
        rating = 3
    }
    @IBAction func button4(_ sender: UIButton) {
        resetImage()
        for num in 0...3{
            ratingCollection[num].setImage(image, for: .normal)
        }
        rating = 4
    }
    @IBAction func button5(_ sender: UIButton) {
       resetImage()
        for num in 0...4{
            ratingCollection[num].setImage(image, for: .normal)
        }
        rating = 5
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        for num in 0...4{
            ratingCollection[num].isEnabled = false
        }
        thanksLabel.text = "Rating submitted"
        count += 1
        if(count <= 1){
            print(rating)
        }
        else{
            print("rating submitted")
        }
    }
    
    func resetImage(){
        for num in 0...4{
            ratingCollection[num].setImage(emptyImage, for: .normal)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
