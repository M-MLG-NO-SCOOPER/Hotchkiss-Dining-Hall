//
//  ViewController.swift
//  HDH
//
//  Created by Student on 11/15/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import UIKit
import WebKit

var testMeals: [MealItem] =
    [MealItem(name: "Frosted Flakes", descript: "cereal", station: .cerealBar, filter: [FilterItem.category["V"]!]), MealItem(name: "Sriracha Chicken", descript: "grilled chicken with sriracha sauce", station: .mainLine, filter: [FilterItem.category["DF"]!, FilterItem.category["GF"]!]), MealItem(name: "Clam Chowder", descript: "New England Chowdah", station: .soupStation, filter: [FilterItem.category["L"]!]), MealItem(name: "Caramelized Onions", descript: "caramelized", station: .sandwhichBar, filter: [FilterItem.category["FF"]!, FilterItem.category["O"]!])]

class ViewController: UIViewController {
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var scSegment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://www.hotchkiss.org/daily-menu")
        let myRequest = URLRequest(url: url!)
        webView.load(myRequest)
 
        //MealItem test
        for meals in testMeals{
            print(meals)
            print("\n")
        }
        
        //RatingItem test
        var testRating = RatingItem(mealItem: testMeals[0])
        testRating.updateRating(newRating: 5)
        print(testRating)
        print("\n")
        
        testRating.updateRating(newRating: 4)
        print(testRating)
        print("\n")
        
        //FilterItem test
        print(Array(FilterItem.category.keys))
        print(Array(FilterItem.category.values))
        
        //print(testMeals.count)
        print(FilterItem.category.count)
    }
    
    @IBAction func segmentedControl(_ sender: Any) {
        let controlIndex = scSegment.selectedSegmentIndex
        if controlIndex == 0{
            let url = URL(string: "https://www.hotchkiss.org/daily-menu")
            let myRequest = URLRequest(url: url!)
            webView.load(myRequest)
        }else{
            let url = URL(string: "https://www.hotchkiss.org/students/dining-services/monthly-menu")
            let myRequest = URLRequest(url: url!)
            webView.load(myRequest)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
