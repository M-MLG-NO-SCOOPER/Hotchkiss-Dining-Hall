//
//  RatingItem.swift
//  HDH
//
//  Created by Student on 11/27/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import Foundation

struct RatingItem: CustomStringConvertible {
    
    var rating: Double
    var mealItem: MealItem
    var ID: Int
    var count: Int
    var total: Double
    
    init(mealItem: MealItem){
        self.rating = 0
        self.mealItem = mealItem
        self.ID = mealItem.myID
        self.count = 0
        self.total = 0
    }
    
    mutating func updateRating(newRating: Double){
        self.count += 1
        self.rating = (Double(total) + newRating)/Double(count)
        self.total = total + newRating
    }
    
    var description: String{
        return "Rating(rating: \(rating), Meal Item: \(mealItem.name), ID: \(ID), Rating Count: \(count), total Rating: \(total))"
    }
}
