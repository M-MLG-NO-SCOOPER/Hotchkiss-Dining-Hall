//
//  FilterItem.swift
//  HDH
//
//  Created by Student on 11/15/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import Foundation

struct FilterItem {
    
    static var category: [String: String] = [
        "DF": "Dairy Free",
        "GF": "Gluten Free",
        "HS": "House Smoked",
        "FF": "Hotchkiss Grown",
        "L": "Local",
        "O": "Organic",
        "V": "Vegetarian",
        "VG": "Vegan"
    ]
}
