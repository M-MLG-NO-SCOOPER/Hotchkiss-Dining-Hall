//
//  FeedbackLoginViewController.swift
//  HDH
//
//  Created by Student on 12/4/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import UIKit

var username = ""

class FeedbackLoginViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.navigationItem.hidesBackButton = true
    }

    @IBAction func googleButton(_ sender: UIButton) {
        if let text = usernameField.text{
            username = text
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
