//
//  FeedbackViewController.swift
//  HDH
//
//  Created by Student on 12/4/18.
//  Copyright © 2018 pronto. All rights reserved.
//

import UIKit

class FeedbackViewController: UIViewController {
    
    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var profileLabel: UILabel!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var tyLabel: UILabel!
    @IBOutlet weak var submitButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpScreen()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        if submitButton.titleLabel?.text! == "Submit"{
            tyLabel.isHidden = false
            textView.isHidden = true
            submitButton.setTitle("Submit Another Response", for: .normal)
        }else{
            tyLabel.isHidden = true
            textView.isHidden = false
            submitButton.setTitle("Submit", for: .normal)
            textView.text = ""
        }
    }
    
    func setUpScreen(){
        //profile picture
        let image = UIImage(named: "profile")
        profile.maskCircle(anyImage: image!)
        
        //text view
        textView.isHidden = false
        textView!.layer.borderWidth = 1
        textView!.layer.borderColor = UIColor.black.cgColor
        
        //profile text
        profileLabel.text = "\(username)@hotchkiss.org"
        
        //thank you label
        tyLabel.isHidden = true
        
        //navigation controller
        self.navigationItem.hidesBackButton = true
        self.navigationItem.title = "Feedback"
    }
}

extension UIImageView {
    public func maskCircle(anyImage: UIImage) {
        self.contentMode = UIViewContentMode.scaleAspectFill
        self.layer.cornerRadius = self.frame.height / 2
        self.layer.masksToBounds = false
        self.clipsToBounds = true
        
        self.image = anyImage
    }
}
